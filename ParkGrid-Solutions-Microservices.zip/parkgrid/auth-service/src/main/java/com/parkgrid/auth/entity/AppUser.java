package com.parkgrid.auth.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "app_users", uniqueConstraints = @UniqueConstraint(name = "uk_username", columnNames = "username"))
public class AppUser {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable=false, unique=true) private String username;
    @Column(nullable=false) private String password;
    @Column(nullable=false) private String role;

    public AppUser() {}
    public AppUser(String username, String password, String role) { this.username=username; this.password=password; this.role=role; }
    public Long getId(){return id;} public String getUsername(){return username;} public String getPassword(){return password;} public String getRole(){return role;}
    public void setUsername(String username){this.username=username;} public void setPassword(String password){this.password=password;} public void setRole(String role){this.role=role;}
}
